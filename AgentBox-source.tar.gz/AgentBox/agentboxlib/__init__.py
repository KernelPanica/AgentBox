"""AgentBox: isolated agent environments."""
